def main():
    print("Hello from pydantic-fastapi-uvicon-demo!")


if __name__ == "__main__":
    main()
