import java.sql.*;

public class Demo_connection 
{

	public static void main(String[] args)
	{
		try 
		{

		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","sam16");
		Statement statement =connection.createStatement();
		statement.executeUpdate("create table infosys_details(eno number, ename varchar(10),esal number)");
		
		System.out.println("Table created successfully");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		connection.close();
		statement.close();
	}

}
