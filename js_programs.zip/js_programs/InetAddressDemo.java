import java.net.*;

public class InetAddressDemo 
{
	public static void main(String args[])throws UnknownHostException
	 {
	   InetAddress ip = InetAddress.getByName("localhost");
	   System.out.println("Protocol is :"+ip.getHostAddress());
	   System.out.println("Host Name is :"+ip.getHostName());
	   System.out.println("Address is : "+ ip.getAddress());
	  /* System.out.println("Address is : "+ ip.isMulticasting());
    	 System.out.println("Address is : "+ ip.isReachable());
	  */

	 }
}