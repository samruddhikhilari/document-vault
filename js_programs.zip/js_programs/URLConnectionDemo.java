import java.net.*;
import java.util.*;

public class URLConnectionDemo
  {
	  public static void main(String args[])throws MalformedURLException
	   {
	     String str;
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enter the URL");
		 str = sc.nextLine();
		 URL url = new URL(str);
		 URLConnection uc = url.openConnection();
		 System.out.println("Protocol is : "+uc.getContent());
		 System.out.println("Host name is : "+uc.getContentType());
		 System.out.println("port is : "+uc.getContentLength());
		 System.out.println("File name is :"+uc.getURL());
		 
		 }
  }