import java.net.*;

public class URLDemo
  {
	  public static void main(String args[])throws MalformedURLException
	   {
		 URL url = new URL("https://msbte.org.in");
		 System.out.println("Protocol is : "+url.getProtocol());
		 System.out.println("Host name is : "+url.getHost());
		 System.out.println("port is : "+url.getPort());
		 System.out.println("File name is :"+url.getFile());
		 System.out.println("String form is : "+url.toExternalForm());
		 System.out.println("Default Port is : "+url.getDefaultPort());
	   }
  }