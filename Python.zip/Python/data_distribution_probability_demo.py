from numpy import random 
list = [3,53,26,43]
result = random.choice(list,p=[0.1,0.4,0.2,0.8],size=(3,2))
result= random.choice(list,size=(3,2))
print(result)