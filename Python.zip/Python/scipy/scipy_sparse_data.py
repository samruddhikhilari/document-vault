import numpy as np
from scipy.sparse import csr_matrix
arr = np.array([4,0,53,63,0,26,0,3])

'''
sparse data = data which is not in used unusdful data 

print(csr_matrix(arr))
print(csr_matrix(arr).count_nonzero())
print(csr_matrix(arr).eliminate_zeros())
print(csr_matrix(arr).sum_duplicates())
'''
#csr to csc 

'''
CSR = reads row after another row
csc = reads column wise 0th index of all col's then 1st 
'''
arr = np.array([[4,0,53,0,0,3],[43,66,0,2,6,0]])

datacsr = csr_matrix(arr)
print(datacsr)
print('\n',datacsr.tocsc())