'''
math = > formulaz 
programming => syntax
scipy = > optimizers 
optimizers - > set of procedure, to define something (method) to find out the root of the method returns object of method
root:: Inputs.. 'fun', x0 
minimize:: Inputs.. 'fun', x0 ,method
maximize::  Inputs.. 'fun', x0 ,method
'''

from math import cos
from scipy.optimize import root
#root method used
def find(x):
    return x + cos(x)

val =  root(find,0)
# print(val)
print(val.x)

'''
from math import cos
from scipy.optimize import maximize
#maximize method used
def find(x):
    return x + cos(x)

val =  maximize(find,0,method='BFGS')
# print(val)
print(val.x)'''


from math import cos
from scipy.optimize import minimize
#minimize method used
def find(x):
    return x + cos(x)

val =  minimize(find,0,method='BFGs')
# print(val)
print(val.x)

    