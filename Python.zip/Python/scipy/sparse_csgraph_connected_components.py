import numpy as np 
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components
arr = np.array([[0,1,2],[1,0,0],[2,0,0]])

#return_predecessor, indices, limit(max weight)

data = csr_matrix(arr)
# print(connected_components(data))

from scipy.sparse.csgraph import dijkstra
print(dijkstra(data,return_predecessors=True,indices=3))

from scipy.sparse.csgraph import floyd_warshall
print(floyd_warshall(data,return_predecessors=True,indices=3))

from scipy.sparse.csgraph import bellman_ford
print(bellman_ford(data,return_predecessors=True,indices=3))

from scipy.sparse.csgraph import depth_first_order
print(depth_first_order(data,return_predecessors=True,indices=3))

from scipy.sparse.csgraph import breadth_first_order
print(breadth_first_order(data,return_predecessors=True,indices=3))

