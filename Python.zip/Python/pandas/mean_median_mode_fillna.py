import pandas as pd

df = pd.read_csv('file1.csv')
print(df.to_string())
#mean
# x = df['cal'].mean()
# df['cal'].fillna(x,inplace=True)
# print(df)

#median
# x = df['cal'].median()
# df['cal'].fillna(x)
# print(df)

#mode
# x = df['cal'].mode()
# df['cal'].fillna(x)
# print(df)