import pandas as pd
df = pd.read_csv('file1.csv')
print(df.duplicated())
df.drop_duplicates(inplace=True)
print(df)