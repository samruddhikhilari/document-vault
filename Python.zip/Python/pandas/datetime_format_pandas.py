import pandas as pd
df = pd.read_csv('file1.csv')
df['duration']=pd.to_datetime(df['duration'])
df.dropna(subset='duration',inplace=True)
print(df.to_string())
print(df.info())
print(df.index)
print(df.drop(26,inplace=True)) #drop method to delete any row 
print(df)
