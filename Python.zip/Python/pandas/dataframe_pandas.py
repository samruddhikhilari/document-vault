import pandas as pd
#dataframe with two dimensional list
x =[[3,24,364,23],[85,43,2,32]]
y = pd.DataFrame(x)
print(y)

#dataframe with dictionary
data = {'name':['a','b','c','d'],'age':[23,21,53,21]}
df = pd.DataFrame(data,index=['one','two','three','four'])
print(df)

# # acces single row from dataframe 
# print(df.loc['one'])
# print(df.loc[['two','three']])

# #particular cell from the dataframe 
# print(df.loc['four','age']) #21

#acces any column
print(df[['name','age']])

#drop particular row
print(df)
df = df.drop('three') #chages original data 

# modification of the data inside the dataframe
df.loc['two','age']= 25
print(df)

# df['marks']=[98.9,97,99,98.6]
# print(df)

#dataframe from 2 series 
cal =[32,32,43,42]
duration =[60,30,120,180]
print(pd.Series(cal)) #print(pd.DataFrame(cal))
print(pd.Series(duration))

data ={'cal':[32,32,43,42],
        'duration':[60,30,120,180]
}
dataframe = pd.DataFrame(data,index=['day1','day2','day3','day4'])
print(dataframe)
# print(dataframe.loc[[1,2]])