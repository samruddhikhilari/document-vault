import pandas as pd
'''
#dropping null values 
df = pd.read_csv('file1.csv')
print(df)
df2 = df.dropna()
print(df2)

#droppng NAN(null) values from original
df = pd.read_csv('file1.csv')
df.dropna(7,inplace=True)
print(df)
'''
#dropping only particular value
df = pd.read_csv('file1.csv')
print(df)
df['cal'].dropna()

df = pd.read_csv('file1.csv')
print(df)
df.fillna(12,inplace=True)
print(df)