import pandas as pd 
data = pd.read_csv('file1.csv')
print(data.to_string())

#max rows 
print(pd.options.display.max_rows)
pd.options.display.max_rows = 25
print(pd.options.display.max_rows)
print(data.to_string())
