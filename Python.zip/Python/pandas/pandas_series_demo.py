import pandas as pd

x=[3,42,53,23]
# y = pd.Series(x)
# print(y)

#access series(column of the table)dataframe using index(label)
# print(y[0::2])

#change indexes of the series as per requirement

y = pd.Series(x,index=['first','second','third','fourth'])
print(y)
print(y['second'])

#generate series of pandas with dictionary
data = {'name':'abc','age':20,'marks':98.9}
dic = pd.Series(data,index=['name','marks','age'])
print(dic)

#generate series of only two elements 
data = {'name':'abc','age':20,'marks':98.9}
dic = pd.Series(data,index=['name','marks'])
print(dic)