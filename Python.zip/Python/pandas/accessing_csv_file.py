import pandas as pd 
data = pd.read_csv('file1.csv')
# print(data.to_string())
print(data.head())
print(data.head(15)) 

print(data.tail())
print(data.info())

