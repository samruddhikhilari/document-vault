import pandas as pd
df = pd.read_csv('file1.csv')
print(df)
#           - changing to right data 
#wrong data  -
#             droping the wrong data 

#changing to right data 
df.loc[5,'duration']=45
df.loc[5,'cal']=45
print(df)

#droping the wrong data 
df.dropna(subset='cal',inplace=True)
print(df)
df.dropna()
