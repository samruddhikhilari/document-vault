#dropping null from all columns
import pandas 
df = pandas.read_csv('file1.csv')
# print(df.dropna())  # drop NAN (null) cells from a table i.e from all columns

# df1 =df['cal'].dropna()
# print(df1)  # drop nan from cal only 
# print(df['duration'])

