import numpy as np
print('1D')
# a1 = np.array([1,2,3,4,5])
# a2 = np.array([6,7,8,9,10])
# a3 = np.concatenate((a1,a2))
# print(np.array_split(a3,5))
# print(np.array_split(a3,8))

print('2D')
a1 = np.array([[1,2,3,4,5],[6,7,8,9,10]])
a2 = np.array([[11,12,13,14,15],[16,17,18,19,20]])
# a3 = np.concatenate((a1,a2))
a3 = [[1,2,3,4,5],
      [6,7,8,9,10],
      [11,12,13,14,15],
      [16,17,18,19,20]]
print(a3)
# print(np.array_split(a3,5,axis=1)) #1] (0)i.e vertical (row vice) 2] (1)i.e horizontal column vise
print(np.hsplit(a3,5)) 
print(np.vsplit(a3,4))
