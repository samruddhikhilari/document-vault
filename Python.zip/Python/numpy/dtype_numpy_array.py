import numpy as np
array = np.array([[38,12,34,43,23,87],[8,2,3,439,233,827]],dtype='S')
print(type(array))
print(array.dtype)
print(array.ndim)

arr1 = np.array(['1','2','3'],dtype='i')
print(arr1)
print(type(arr1))
print(arr1.dtype)