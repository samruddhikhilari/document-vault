import matplotlib.pyplot as plt
import seaborn as sns
from numpy import random

array = random.binomial(n=1,p=0.5,size=(2,3))
print(array)

sns.displot(array,kde=True)
plt.show()