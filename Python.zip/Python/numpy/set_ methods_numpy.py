import numpy as np

array1 = np.array([32,4,36,41,64,4,36,41])
print(np.unique(array1)) # unique values 

array1 = np.array([32,4,36,41,64,4,36,41])
array2 = np.array([332,234,326,41322,64,4,36,41])
print(np.union1d(array1,array2)) # unique of two 

array1 = np.array([32,4,36,41,64,4,36,41])
array2 = np.array([332,234,326,41322,64,4,36,41])
print(np.intersect1d(array1,array2)) # common of two 

array1 = np.array([32,4,36,41,64,4,36,41])
array2 = np.array([332,234,326,41322,64,4,36,41])
print(np.setxor1d(array1,array2)) # uncommon of two 

array1 = np.array([32,4,36,41,64,4,36,41])
array2 = np.array([332,234,326,41322,64,4,36,41])
print(np.setdiff1d(array1,array2)) # present in one not in second array 





