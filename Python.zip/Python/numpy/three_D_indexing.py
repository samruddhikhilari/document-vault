import numpy as np
# array = np.array([3,24,464,3],ndmin=3)
# print(array)

array = np.array([[[1,2,3],[4,5,6]],[[7,8,9],[10,11,12]]])
print(array)
print(array[1,1,0])
print(array[1,1,:])
print(array[0,1,0])
print(array[0,1,2])
