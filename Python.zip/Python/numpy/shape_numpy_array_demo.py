#shape => method returns number of dimensions with count of elements within an array 
#1-D array 
import numpy as np
array1 = np.array([3,2,32,52,28])
print(array1)
print(array1.shape)
 
 #2-D array
array2 = np.array([[3,2,32,52,28],[34,22,3,5,2]])
print(array2)
print(array2.shape)

#3-D array
array3 = np.array([[[[3,23,4,26,23,6],[44,4,3,26,47,245]],[[30,223,45,276,233,68],[314,326,474,46,34,245]]],[[[3,23,4,26,23,6],[44,4,3,26,47,245]],[[30,223,45,276,233,68],[314,326,474,46,34,245]]]])
print(array3)
print(array3.shape)


