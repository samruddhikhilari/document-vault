import numpy as np
print('1D')
a1 = np.array([1,2,3,4,5])
a2 = np.array([6,7,8,9,10])
print(np.hstack((a1,a2)))
# print(a1)
# print(a2)
# print(np.concatenate((a1,a2)))
print('2D')
a1 = np.array([[1,2,3,4,5],[6,7,8,9,10]])
a2 = np.array([[11,12,13,14,15],[16,17,18,19,20]])
# np.max(a1)
# np.add(a1,a2)
# np.average(a1)
# print(np.concatenate((a1,a2)))
# print(np.concatenate(np.concatenate((a1,a2),axis=0)))
print(np.stack((a1,a2)))  # combines multiple arrays in one data 
print(np.hstack((a1,a2)))  #column vise (horizontal) (0,0) like that 
print(np.vstack((a1,a2))) #row vise ()vertical approach
print(np.dstack((a1,a2))) # hstack's hstack (depth stack)




