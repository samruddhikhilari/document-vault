#1-D array 
import numpy as np
print('1-D array')
array1 = np.array([3,2,32,52,28])
for i in array1:
    print(i,end=' ')
print('\n 2-D array')
 #2-D array
array2 = np.array([[3,2,32,52,28],[34,22,3,5,2]])
for i in array2:
    for j in i:
        print(j,end=' ')
    print('\n')   
print('\n 3-D array')
#3-D array
array3 = np.array([[[3,23,4,26,23,6],[44,4,3,26,47,245]],[[30,223,45,276,233,68],[314,326,474,46,34,245]]])
print(array3.shape)
for i in array3:
    for j in i:
        for k in j:
            print(k,end=' ')
        print('\n')