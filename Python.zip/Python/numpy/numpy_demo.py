import numpy

array = numpy.array((37,253,28,353))
print(array)
print(type(array))

print(numpy.flip(array))
print(numpy.arange(0,11,2))
print(numpy.max(numpy.arange(100,1,-1)))

data=numpy.arange(0,100,2,dtype=set)
print(type(data))
print(data)
