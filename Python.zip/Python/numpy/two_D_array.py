import numpy as np
array = np.array([[38,12,34,43,23,87],[8,2,3,439,233,827]])
print(array[1,3])
print(array[0:])
print(array[0,1])
print(array[1,4])
