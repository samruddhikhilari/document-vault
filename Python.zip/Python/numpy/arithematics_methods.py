#arithematics method of numpy module
import numpy as np
array1 = np.array([3,253,532,61,3])
array2 = np.array([47,583,3,6,2])
array3 = np.add(array1,array2) # array1[0]+array2[0]
print(array3)

array1 = np.array([3,253,532,61,3])
array2 = np.array([47,583,3,6,2])
array3 = np.subtract(array2,array1)
print(array3)

array1 = np.array([3,253,532,61,3])
array2 = np.array([47,583,3,6,2])
array3 = np.multiply(array1,array2)
print(array3)

array1 = np.array([3,253,532,61,3])
array2 = np.array([47,583,3,6,2])
array3 = np.divide(array1,array2)
print('divide is : ',array3)

array1 = np.array([3,253,532,61,3])
array2 = np.array([47,583,3,6,2])
array3 = np.mod(array1,array2)
print(array3)

array1 = np.array([3,253,532,61,3])
array2 = np.array([47,583,3,6,2])
array3 = np.remainder(array1,array2)
print(array3)

array1 = np.array([3,253,532,61,3])
array2 = np.array([47,583,3,6,2])
array3 = np.divmod(array1,array2)
print(array3)

array1 = np.array([3,-253,532,61,3])
array2 = np.array([47,-583,-3,-6,2])
array3 = np.absolute(array1,array2)
print(array3)

array1 = np.array([3,253,532,61,3])
array2 = np.array([47,583,3,6,2])
array3 = np.power(array1,array2)
print(array3)