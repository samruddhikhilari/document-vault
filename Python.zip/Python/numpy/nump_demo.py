import numpy as np

print('numerical python array with list elements :')
l = np.array([38,263,28,263,16,])
print(l)
print(type(l))
print()
print('numerical array with tuple elements :')
t = np.array((36,26,5,23,13,38))
print(type(t))
print(t)