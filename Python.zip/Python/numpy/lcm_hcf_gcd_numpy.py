import numpy as np
array1 = 9
array2 = 6
print(np.lcm(array1,array2))

array1 = np.array([1,2,3,4])
array2 = np.array([7,8,9,10])
print(np.lcm(array1,array2))

array1 = 9
array2 = 6
print(np.gcd(array1,array2))

array1 = np.array([1,2,3,4])
array2 = np.array([7,8,9,10])
print(np.gcd(array1,array2))
np.lcm()

'''
1. LCM 
[Lowest common factor]
2. HCF
Hightest Common factor
[Greatest Commond factor/divisible]
'''