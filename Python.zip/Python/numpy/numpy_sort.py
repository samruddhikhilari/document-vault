import numpy as np
a1 = np.array([132,23,3,24,5])
print(a1)
print(np.sort(a1)) # sorting in asecending
data =np.sort(a1)
print(data.reversed(True)) #sorting in ascending and reverse it (i.e converts to the descending order)
