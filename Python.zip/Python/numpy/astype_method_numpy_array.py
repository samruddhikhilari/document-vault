import numpy as np
array = np.array([1,2,3,45],dtype='i')
print(array)
# arr2 = array # gives reference
arr2 = array.copy() # generates copy instead of giving reference
arr3 = array.view()
print(arr2)
array[3]=32
print(arr2)
print(arr3)

arr4 = array.astype(float) # astype('f')
print(arr4.dtype)
