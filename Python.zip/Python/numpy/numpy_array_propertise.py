import numpy
array = numpy.array([3,23,53,54,64],ndmin=3,dtype=int)
print(array)
print(type(array))
print(array.ndim)
print(array.dtype)