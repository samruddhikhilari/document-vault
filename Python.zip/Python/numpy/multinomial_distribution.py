import matplotlib.pyplot as plt
import seaborn as sns
from numpy import random

array = random.multinomial(n=2,pvals=1)
print(array)

sns.displot(array)
plt.show()