import numpy
print(numpy.array([38,256,45,97,54],ndmin=2))
print(numpy.ones(3))
print(numpy.zeros(5))
print(numpy.arange(3,21,1))
print(numpy.linspace(1,10,num=4))
print(numpy.empty(3))
