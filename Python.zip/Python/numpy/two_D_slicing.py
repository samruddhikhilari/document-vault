import numpy as np
array = np.array([[38,12,34,43,23,87],[8,2,3,439,233,827]])
print(array)
print(array[1,1:4])
print(array[:6:2])
print('h') #below first array then ele
print(array[0:2,0]) # stat:end, of ele's
print(array[0,0:2]) # ele's stat:end
print(array[0:2,0:4]) # stat to:end ele and with stat:end val
