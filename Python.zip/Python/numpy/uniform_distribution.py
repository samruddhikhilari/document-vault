import matplotlib.pyplot as plt
import seaborn as sns
from numpy import random

array = random.uniform(size=(2,3))
print(array)

sns.displot(array)
plt.show()