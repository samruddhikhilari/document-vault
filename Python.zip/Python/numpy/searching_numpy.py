import numpy as np
a1 = np.array([1,2,3,4,5])
print(a1)
print(np.where(a1%2 == 0)) # print(a1%2 ==0) returns even values indexes
a3 = a1%2 ==1 #
print('filtering array ')
print(a1[a3])
print(np.searchsorted(a1,5)) # searching in sorted array
