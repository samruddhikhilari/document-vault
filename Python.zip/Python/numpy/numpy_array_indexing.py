import numpy as np
#generate an array with the help of numpy
array = np.array([36,263,19,10,36,46,567])
print(array)
print('\n Array indexing :')
print(array[2])
print(array[4])
print(type(array[0] == array[4]))
print(array[-4])
print(array[::2])