import numpy as np
#rounding decimal value through numpy functions
array1 = np.array([3.32,253.74,53.247,61.3])  #array1[0]>=5 +1 otherwise +0
array2 = np.around(array1)
print(array2)

array1 = np.array([-3.32,253.74,53.247,-61.3])  # -4 -3.32 -3 0 3 3.53 4 [c->f]left to the right
array2 = np.ceil(array1)                      # ceil ----->
print(array2)                                 #array1[0]= -3.32 -->-3

array1 = np.array([-3.32,253.74,53.247,-61.3])  # -4 -3.32 -3 0 3 3.53 4 [c<-f]right to the left 
array2 = np.floor(array1)                      # floor <-----
print(array2)                                 #array1[0]= -3.32 <--- -4

array1 = np.array([3.32,253.74,53.247,61.3])  # remove no's after (.)decimal but float no to float number  
array2 = np.trunc(array1)
print(array2)

array1 = np.array([3.32,253.74,53.247,61.3])  # same as truncate
array2 = np.fix(array1)
print(array2)



