import matplotlib.pyplot as plt
import seaborn as sns
from numpy import random

array = random.poisson(lam=2,size=(2,3))
print(array)

sns.displot(array)
plt.show()