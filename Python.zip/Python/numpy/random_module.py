import numpy as np

# from numpy import random

print(np.random.rand(3,3,2)) # array ,rows and columns(size) inputs as size (range already givens)
print(np.random.randint(1,100,size=(3,2)))
print(np.random.randint(1000,2000,10))
print(np.random.ranf(10))
list = [3,32,57,67,475,654,432,5,352,23]
print(np.random.choice(list,91)) #data, count of ele's 

'''
1.range already given
  :rand()
  :ranf()
2. rage takes form user
   :randint()

3. size (shape of array)
    :rand()
    :ranf()
    :randint()
'''