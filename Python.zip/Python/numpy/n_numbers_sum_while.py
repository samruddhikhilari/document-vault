n = int(input('ente nth number to find sum'))
#find sum of numbers
i=0
sum=0
while(i<=n):
    sum+=i
    i+=1

print('sum of',n,'th numbers is :',sum)

#find factorial
# j=1
# while(j<=n):
#     fact*=j
#     j+=1

fact=1
for j in range(1,n+1):
    fact*=j
print('factorial of the', n ,'th nos is :',fact)