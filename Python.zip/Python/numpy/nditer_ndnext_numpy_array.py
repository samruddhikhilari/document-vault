#1-D array 
import numpy as np
print('1-D array')
array1 = np.array([3,2,32,52,28])
a1 = np.nditer(array1)
print(next(a1))
print(next(a1))
print(next(a1))
print(next(a1))
print(next(a1))

#nditer converts nd elements in single array element that can be access through use of only single for loop
#2-D array
print('\n 2-d Array')   
array2 = np.array([[3,2,32,52,28],[34,22,3,5,2]])
a2 = np.nditer(array2)
for i in a2:        
    print(i,end=' ')

print('\n 3-D array')
#3-D array
array3 = np.array([[[3,23,4,26,23,6],[44,4,3,26,47,245]],[[30,223,45,276,233,68],[314,326,474,46,34,245]]])
a3 = np.nditer(array3)
for i in a3:
    print(i,end=' ')
