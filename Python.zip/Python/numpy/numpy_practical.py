import numpy as np
print(np.__path__)
print(np.__version__)
print(np.__annotations__)
print(np.__name__)
print(np.__package__)
# print(np.info())