import numpy as np
array = np.random.choice([43,64,32,61],2)
print(array)
print(np.random.permutation(array))

print(np.random.shuffle([32,2,16]))