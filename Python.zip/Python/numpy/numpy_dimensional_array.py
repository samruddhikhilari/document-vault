import numpy 
print('0-D array')
# array with no dimension means no array i.e only single value 
a0 = numpy.array(38)
print('0-d',a0)
print('1-D array')
a1 = numpy.array([3,5,6,7])
print('1-D',a1,end='\n')
print('2-D array')
a2 = numpy.array([3,3,23,54,64],ndmin=2)
print('2D',a2)
print('3-D array')
a3 = numpy.array([
    [
        [3,3,23,54,64],[3,3,23,54,64]
    ],
    [
        [3,3,23,54,64],[3,3,23,54,64]
    ],
    [
        [3,3,23,54,64],[3,3,23,54,64]
    ]
        ])
print('3D',a3)
