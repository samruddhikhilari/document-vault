import numpy as np
#arithematics method of numpy module
'''
 add->sum->cumsum(cummative sum)
 substract->diff(takes arrays as single argument)
 multiply->prod->cumprod
 divide->quotient

array1 = np.array([3,253,532,61,3])
array2 = np.array([47,583,3,6,2])
array3 = np.sum([array1,array2]) # array1[0]+array1[1]+array1[n] + array2[0]+array2[n] adding all elements 
print(array3)

array1 = np.array([3,253,532,61,3])
array2 = np.array([47,583,3,6,2])
array3 = np.cumsum([array1,array2]) # just like prefix sum
print(array3)
'''
array1 = np.array([100,200,500,600,400]) #right to left substraction
array2 = np.array([50,583,3,6,2])
array3 = np.diff([array1,array2])
print(array3)
array1 = np.array([3,253,532,61,3])
array2 = np.array([47,583,3,6,2])
array3 = np.prod([array1,array2])
print(array3)
'''
array1 = np.array([3,2,1,4,3])
array2 = np.array([8,583,3,6,2])
array3 = np.cumprod([array1,array2])
print(array3)

print()
print()
array1 = np.array([3,2,1,4,3])
array2 = np.array([8,583,3,6,2])
array3 = np.cumprod([array1,array2],axis=1)
print(array3)
'''
