import numpy as np
array1 = np.array([3,1,30,5,32,65])
print(array1)
# print(array1.reshape(3,3))
print(array1.reshape(2,3)) #[[ 3  1 30  5 32][65 74 34 46 45]]
# print(array1.reshape(2,2,-1))
array2 = array1.reshape(3,2)
print(array2.reshape(-1))