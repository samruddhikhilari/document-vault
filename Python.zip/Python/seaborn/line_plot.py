import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

colleges=[32,42,23,62,92]
students=[3,26,32,62,23]
ds = pd.DataFrame({'colleges':colleges,'students':students})
# sns.lineplot(x=colleges,y=students,data=ds)
sns.lineplot(ds)
plt.show()