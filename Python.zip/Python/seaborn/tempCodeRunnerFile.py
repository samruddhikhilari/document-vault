sns.barplot(x='island',y='bill_length',data = ds,order=['bharat','india'],hue=ds['sex'])
sns.barplot(x='island',y='bill_length',data = ds,order=['bharat','india'],hue_order=ds['sex'])