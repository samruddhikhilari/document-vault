import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

code= [32,53,26,431,32,53,26,431]
bill_length=[36.7,39.3,38.9,41.1,36.7,39.3,38.9,41.1]
total = [3,26,431,63,6,2,6,21,]
ds = pd.DataFrame({'code':code,'bill_length':bill_length,'total':total})
sns.heatmap(data = ds,linewidth=10,annot=True)
sns.set(xlabel='xlabel')
sns.set(ylabel='ylabel')
sns.set(font_scale=10)
plt.show()

''' Properties
cbar = bool
vmin = intval
vmax = intval
linewidth = intval
linecolor= color
annot=bool
annot_kws= fontdict
cmap = mapname
xticklabel = label or bool
yticklabel = label or bool
set()= to style the plot
'''
