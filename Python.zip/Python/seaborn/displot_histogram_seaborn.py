import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

colleges=[32,42,23,62,92]
students=[3,26,32,62,23]
ds = pd.DataFrame({'colleges':colleges,'students':students})

# sns.displot(ds,kde=True,bins=[0,20,40,60,80,100],rug=True,color='blue')
sns.displot(ds,kde=True,rug=True,color='blue',log_scale=True)

plt.show()

'''
kde => kernel estimation(output notation line)
bins=> helps to get full range for one box(bin)
rug => occupy lines at the bottom
color
'''