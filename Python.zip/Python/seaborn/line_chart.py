import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

age = [32,52,14,63,23]
weight=[143,432,641,643,236]
gender =['female','male','others','female','female']

dic={'age':age,'weight':weight,'gender':gender}
dataset = pd.DataFrame(dic)

# sns.lineplot(x=age,y=weight,data=dataset)
# plt.show()
#plotting with gender's
sns.lineplot(x=age,y=weight,data=dataset,hue='age',palette='summer',style='gender',markers=['*','o','P'],markersize=10)
plt.show() 