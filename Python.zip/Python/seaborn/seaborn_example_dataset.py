import matplotlib.pyplot as plt
import seaborn as sns

ds = sns.load_dataset('penguins.csv').head(10)
sns.lineplot(x='col1',y='col2',data=ds,hue='col3')
plt.grid()
plt.title('Line plot from the seaborn package')
plt.show()