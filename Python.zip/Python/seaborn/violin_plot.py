import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

ds =pd.DataFrame({'island':['india','australia','bharat','general'],'bill_length':[36,39,38,41],'sex':['female','male','others','female']})
sns.violinplot(x=ds['island'],data=ds,linewidth=10,split=True)
sns.set_style('whitegrid')
plt.show()

''' propeties
data = dataframe
x = series
y= series
hue = series for categories
order = arrangement as per given series order
palette = cmap
split = bool
'''