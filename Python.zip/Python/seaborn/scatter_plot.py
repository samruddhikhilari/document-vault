import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

ds = {'island':['india','australia','bharat','general'],'bill_length':[36.7,39.3,38.9,41.1],'sex':['female','male','others','female']}
sns.scatterplot(x=ds['island'],y=ds['bill_length'],data=ds,style=ds['sex'],palette='winter',hue=ds['sex'],sizes=[79,88,89,98],alpha=1)
plt.show()
