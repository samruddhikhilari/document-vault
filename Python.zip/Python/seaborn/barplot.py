import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

ds = {'island':['india','australia','bharat','general'],'bill_length':[36.7,39.3,38.9,41.1],'sex':['female','male','others','female']}
sns.barplot(x='island',y='bill_length',data = ds,order=['bharat','india'],hue=ds['sex'])
sns.barplot(x='island',y='bill_length',data = ds,order=['bharat','india'],hue_order=ds['sex'])
# sns.barplot(y='island',x='bill_length',data = ds,orient='h',palette='summer',saturation=0.5,alpha=0.5)
sns.barplot(x='island',y='bill_length',data = ds,orient='v',palette='icefire',saturation=5,alpha=0.5,errorbar=10)

plt.show()
