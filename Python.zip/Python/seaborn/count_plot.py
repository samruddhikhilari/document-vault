import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

ds =pd.DataFrame({'island':['india','australia','bharat','general'],'bill_length':[36.7,39.3,38.9,41.1],'sex':['female','male','others','female']})
sns.countplot(data=ds,linewidth=10,hue=ds['sex'])
plt.show()

''' propeties
data = dataframe
x = series
y= series
hue = series for categories
order = arrangement as per given series order
palette = cmap

'''