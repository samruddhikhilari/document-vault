class Circle:
    def __init__(self,rad):
        self.radius = rad
    
    def area(self):
        self.area = 3.14*(self.radius**2)
        print('Area of the circle is :',self.area)

    def perimeter(self):
        self.area = 2*3.14*self.radius
        print('Perimeter of the circle is :',self.area)

radius =float(input('enter radius of the circle'))
c = Circle(radius)
c.area()
c.perimeter()