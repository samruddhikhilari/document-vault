# with open('./numbers.txt','r') as file:

    # data = file.read()
stat=True
while (stat):
    data="13,88,24,95,3,5,7,9,4"
    # print(data)
    # print(type(data))
    i=0
    num=''
    count=0
    # while i<len(data):
    #     if(data[i]==','):
    #         print(num)
    #         if(int(num)%2 ==0):
    #             count+=1
    #         num=''
    #     else:
    #         num+=data[i]
    #     i+=1
    
    list=data.split(',')
    for val in list:
        if(int(val) %2 ==0):
            count+=1
            print(val)
    print('Number of even numbers in file is :',count)
    stat=False