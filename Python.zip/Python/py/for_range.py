print('**************************************')
print('values in descending order',end='\n\n')
for val in range(100,0,-1):
    print(val)

print('**************************************')
print('defaulty starts from 0 increment by1 to specified end 101 i.e upto 100',end='\n\n')
for val in range(101): # defaulty starts from 0 increment by1 to specified end 101 i.e upto 100
    print(val)

print('**************************************')
print('print 1 to 101 odd numbers',end='\n\n')
for val in range(1,101,2):   #print 1 to 101 odd numbers
    print(val)

print('**************************************')
print('print 2 to 101 even numbers',end='\n\n')
for val in range(2,101,2):   #print 2 to 101 even numbers
    print(val)