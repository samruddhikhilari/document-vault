import numpy
array = numpy.array([38,263,92,64])
print('Array traversing by for loop ')
for i in array:
    print(i,end=' ')
print('\nArray traversing through iter and next ')
arr1= iter(array)
print(next(arr1))
print(next(arr1))
print(next(arr1))
print(next(arr1))