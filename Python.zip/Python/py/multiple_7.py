num= int(input("enter the number"))
if(num%7==0):
    print(num,"multiple by 7")
else:
    print(num,"not multiple by 7")