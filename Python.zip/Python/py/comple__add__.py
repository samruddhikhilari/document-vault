class Demo:
    def __init__(self,real,img):
        self.real=real
        self.img=img

    def show(self):
        print(self.real,"+",self.img,'j')

    def __add__(self,obj):
       self.newreal = self.real + obj.real
       self.newimg = self.img + obj.img

       print ('add: ',self.newreal,"+",self.newimg,'j')
    
d1 = Demo(32,34)
d2 = Demo(27,12)
d1.show()
d2.show()
d1 + d2 
