n = int(input('enter table number'))

print('**************************')
print("Table of ",n)
print('**************************')

for var in range(1,11):
    print(n,'*',var,'= ',(n*var))