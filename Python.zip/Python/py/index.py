str = "we are students "
print("substring is :",str)
print(str[:])
print(str[3:9])
print(str[0:])
print(str[:len(str)])
print(str[-9:-1])