class Student:
    def __init__(self,name):
        self.name=name
    
    def show(self):
        print(self.name)

s1 = Student('abc')
s1.show()

s2 = Student('xyz')
s2.show()

# del s1.name  #delete  name property of s1 object
# del s1   #delete s1 object
# s1.show()  #it will show s1 not defined error