def show(n):
    print('function calls ',n,'th times')
    if(n>0):
         return (n * show(n-1) )
    else:
         return 1
    
no = int(input('enter count of n '))
print(show(no))