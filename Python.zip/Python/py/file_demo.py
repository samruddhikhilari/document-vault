file = open("firsfile.txt",'r+') #mode in open as second argument r and b is default 
if (file != None):
    print(file.readline())
    file.write('\nthis is an first')
file.close()

