with open("secondfile.txt",'w') as f:
    f.write('this is second file\n created by python')
    f.close()

with open("secondfile.txt","a") as f1:
    f1.write('second file is second time edited \n created by python')
    f1.close()

with open("fourthfile.txt","x") as f2:
    f2.write('this is third file\n created by python')
    f2.close()