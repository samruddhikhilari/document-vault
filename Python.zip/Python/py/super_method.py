class Car:

    def __init__(self,name):
        self.name = name

    def show(self):
        print('show name',self.name)

class ToyotoCar(Car):
    def __init__(self,type):
        super().__init__('fortuner')
        self.type = type

    def show(self):
        super().show()
        print('show type',self.type)

t1 = ToyotoCar('new') 
t1.show()



