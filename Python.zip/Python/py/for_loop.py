for var in range(1,11):   #range(start?,stop,step?)
    print(var)
else:
    print('else executes when for loop iterations traversal get completed')