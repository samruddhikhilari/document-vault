tuple = (38,7,45,2,24,38,352,28,12)
print(tuple[1])
print("\n")
print("given tuple is : ",tuple)

x = int(input('enter find number'))
i=0
while i<len(tuple):
    if(tuple[i]==x):
        print(x,"found at position of",i+1)
    i+=1
