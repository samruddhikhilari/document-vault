class Employee:
    def __init__(self,role,dep,sal):
        self.role = role
        self.dep = dep
        self.sal = sal

    def showDetails(self):
        print(self.role)
        print(self.dep)
        print(self.sal)

class Engineer(Employee):
    def __init__(self,name,age):
       self.name = name
       self.age = age
       role = input('enter employee role')
       dep = input('enter employee department')
       sal = float(input('enter employee salary'))
       super().__init__(role,dep,sal)

    def showDetails(self):
        print(self.role)
        print(self.dep)
        print(self.sal)
        print(self.name)
        print(self.age)

name = input('enter employee name')
age = float(input('enter employee age'))
en = Engineer(name,age)
en.showDetails()