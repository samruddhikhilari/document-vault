age = 89
if(age>=18):
    if(age<=80):
        print("you can drive")
    else:
        print("your exceeded the age limit")
else:
    print("you can't drive")

        
    