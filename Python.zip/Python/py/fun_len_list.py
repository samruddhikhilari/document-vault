def find(list):
    return(len(list))

print(':::::::::::: enter value for list items:::::::::::::::')
a = (input('value of a'))
b = (input('value of b'))
c = (input('value of c'))
d = (input('value of d'))
e = (input('value of e'))
f = (input('value of f'))

list1 =[a,b,c,d,e,f]
print('list elements is :',list1,end=' ')
print('Length of the list :',find(list1))