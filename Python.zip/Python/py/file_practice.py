with open("practice.txt",'x') as f:
    f.write('Hi everyone\n we are learning File I/O \n using Java.')
    f.write('\n I like programming in Java.')

