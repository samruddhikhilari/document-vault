import os
os.remove('thirdfile.txt')