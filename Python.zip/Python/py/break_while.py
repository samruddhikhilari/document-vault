list =['Grapes','Strawberry','BlueBerry','JackFruit','WaterMelon','Mango']
i=0
print('***********************************')
print('List of your favourite fruit')
while i<len(list):
    if(list[i]== 'WaterMelon'):
        print("You can't eat WaterMelon")
        break
    print(list[i])
    i+=1
else :
    print("end of the while loop")
