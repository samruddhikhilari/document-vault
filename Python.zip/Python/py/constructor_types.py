class Student:
    #parameterized constructor
    def __init__(obj,name):
        obj.name=name
        print('parameterized constructor')

    #   #default constructor
    # def __init__(obj):
    #     obj.name='stud'
    #     print("default constructor")
    #     print('Name of the student is : ',obj.name)

s2 = Student('sam')
print(s2.name)
# s1 = Student()
