def fact(n):
    if(n==1):
        return 1
    return(n*fact(n-1))
no = int(input("enter n to find it's factorial"))
print(fact(no))