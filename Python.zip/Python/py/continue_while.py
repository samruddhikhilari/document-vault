list =['Grapes','Strawberry','BlueBerry','JackFruit','WaterMelon','Mango']
i=0
print('***********************************')
print('List of your favourite fruit')
while i<len(list):
    if(list[i]== 'WaterMelon'):
        print("You can't eat WaterMelon")
        i+=1
        continue
    print(list[i])
    i+=1
else :
    print("executes after the termination of for loop's condition ")
