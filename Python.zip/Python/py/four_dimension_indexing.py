import numpy as np
array = np.array([[[[1,2,3],[4,5,6]],[[7,8,9],[10,11,12]]],[[[13,14,15],[16,17,18]],[[19,20,21],[22,23,24]]]])

print(array)
print('================== \n Array indexing \n')
print(array[1,1,0])
print(array[1,1,:])
print(array[0,1,0])
print(array[0,1,1])