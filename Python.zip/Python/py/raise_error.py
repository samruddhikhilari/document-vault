name = input('ENTER YOUR NAME ')
if name:
    print(name)
else:
    raise Exception('please enter value')
print('end statement')