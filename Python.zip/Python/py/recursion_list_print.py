def show(list,i):
    if(i== len(list)):
        return 1
    print(list[i])
    show(list,i+1)
list1 =[37,26,28,'5467','152']
i=0
print('list elements is :')
show(list1,i)