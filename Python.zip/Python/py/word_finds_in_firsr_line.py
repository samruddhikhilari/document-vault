word='learning'
lineno=1
line=True
with open('firsfile.txt','r')as file:
    while line:
        line = file.readline()
        if(word in line):
            print('word find at line of',lineno)
        lineno+=1