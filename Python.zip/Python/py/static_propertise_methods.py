class Student:
    #static property
    college_name='GPA'
    @staticmethod
    def college():
        print('this is a static method can be called by class or object')

#reference of an object
    def show(self):
        print('this is a object specific method ',self.college_name)

#reference of an class
    @classmethod
    def dis(self):
        print('this is a class specific method ',self.college_name)
    
sq = Student()
#call to static method
sq.college()
Student.college()

#call to object refered method
sq.show()

#call to class refered method
Student.dis()

'''
1 static properties OR methods(@staticmethod) can called throught the class as well obj
2. class properties OR methods (@classmethod)can called throught only the class 
3. object properties OR methods can called throught only the obj
'''