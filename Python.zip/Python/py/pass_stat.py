print('Use of pass to forward from one empty phase to another phase without any restriction')
for i in range(100):
    #this is an empty loop
    pass # pass to forward from one empty phase to another phase
else:
    print("this is loop's else statement") #due to pass stat although cond^n true it will executes

if 18>38:
    #empty conditional block
    pass # pass to forward from one empty phase to another phase
else:
    print("this is if's else statement")#due to pass stat although cond^n true it will executes
print('end statement')

