import josn 
#json => java script object notation
#json help to convert data from json to python and vice versa
#json stores each data type value in string

#json to python using loads
pdata= json.loads('[3,24,34,213,64]') 
print(pdata)

pdata= json.loads('{"name":[3,24,34,213,64],"age":[3,24,34,213,64]}') #json to python using loads
print(pdata)

pdata= json.loads('{"name","age","marks"}') #json to python using loads
print(pdata)

#python to jsong data conversion

list =[3,24,34,213,64]
print(json.dumps(list,indent=4,separators={"."," ="},sort_keys=True))

dict ={"name":[3,24,34,213,64],"age":[3,24,34,213,64]}
print(json.dumps(dict))

set = {"name","age","marks"}
print(json.dumps(set))
