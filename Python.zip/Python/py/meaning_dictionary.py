mean ={
    "cat":'a small animal',
    'table':('a piece of furniture','list of facts $ figures')
}
print(mean)
print()
print(mean['table'][1])