class Student:
    def __init__(self,math,phy,che):
        self.math=math 
        self.phy = phy
        self.che= che

    @property
    def cal(self):
        self.per = (self.math+self.phy+self.che)/3
        return(self.per)

s = Student(38,2,53)
print(s.cal)

#chNGE PHY
s.phy = 50
print(s.cal)


