marks=[98.8,93.18,87.88,91,85,82.20]

marks.sort(reverse=True)
print(marks)

marks.sort()
print(marks)

marks.reverse()
print(marks)

marks.append(3738)
print(marks)

list=[98.8,18,'djshd',91,True,'eskss']
print(list)

'''
list is heterogenuous
list is mutable
list is order
'''