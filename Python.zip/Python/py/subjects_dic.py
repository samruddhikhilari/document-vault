dic={}
s1 = int(input("m1"))
s2 = int(input("m2"))
s3 = int(input("m3"))

dic.update({"sub1":s1,})
dic.update({"sub2":s2,})
dic.update({"sub3":s3})
dic["sub4"]=38
print(dic)