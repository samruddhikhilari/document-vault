class Order:
    def __init__(self,item,price):
        self.item=item
        self.price=price

    def show(self):
        print(self.item)
        print(self.price)

    def __gt__(self,obj):
        if(self.price > obj.price):
           print(True)
        else:
            print(False)
    
o1 = Order('abc',100)
o2 = Order('xyz',1000)
o1.show()
o2.show()
o1 > o2 
