class Car:
    def show1(self):
        print('show 1 ')

class ToyotoCar:
    def show2(self):
        print('show 2')

class Fortuner(Car,ToyotoCar):
    def show3(self):
        print('show 3')
        
f1 = Fortuner() 
f1.show1()
f1.show2()
f1.show3()


