class Student:
    def __init__(self,name):

        # _ _ denoted private property
        self.__name=name
    
    def dis(self):
        self.__show()  #access to __ private method within class only can called through another public method


    # _ _ denoted private method
    def __show(self):
        print(self.__name) #access to __ private property within class only
 
s1 = Student('abc')
s1.dis()

#private properties or method can't access out of the class
# s1.__name
# s1.__show()