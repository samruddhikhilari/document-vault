import math
print(math.ceil(-99.6)) #99
print(math.ceil(99.6))#100
print(math.floor(98.7))#98

print(round(98.6)) #99
print(min(38.9,23,52)) #23
print(max(372.3,28,26))#372.3
print(math.sqrt(64))#8
print(math.pow(4,2))#16
print(math.sin(90))
print(abs(-33736))#33736



