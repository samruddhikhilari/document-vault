class Student:
    def __init__(self,name,marks):
        self.name=name
        self.marks=marks
    
    def avg(self):
        sum=0
        for i in self.marks:
            sum+=i
        
        sum/=3
        print(self.name,'average of your marks is :',sum)

s1 = Student('xyz',[100,100,99.9])
s1.avg()