class Account:
    def __init__(self,no,bal):
        self.acc_no=no 
        self.bal=bal

    def debit(self,amount):
        self.bal-=amount
        print('Debit Details')
        print('=======================')
        print('Debit amount is :',amount)
        self.print()
    
    def credit(self,amount):
        self.bal+=amount
        print('Credit Details')
        print('=======================')
        print('Credit amount is :',amount)
        self.print()    

    def print(self):
        print('****************************')
        print('Account no is :',self.acc_no)
        print('Toal Balance amount is :',self.bal)
        print()

a1 = Account('16',1000)
a1.debit(100)
a1.credit(200)
a1.credit(100)

