def welcome(name):
    data = name.split(' ')
    print('Good Morning \n Have a nice day ',data[0])

