from mymodule import welcome
name = input('enter your name :')
welcome(name)