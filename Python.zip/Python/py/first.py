string ="the price of $ is $ of $400"
print("presence of $ is",string.count("$"))
