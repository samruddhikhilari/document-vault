def show(self):
        print('show name',self.name)