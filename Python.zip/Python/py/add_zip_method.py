import numpy as np
array1 = np.array([2,4,5,36])
array2 = np.array([8,9,86,42])
array3=[]
#zip
for i,j in zip(array1,array2):
    array3.append(i+j)
    print(array3)
#add
array4 = array1+array2
print(array4)
