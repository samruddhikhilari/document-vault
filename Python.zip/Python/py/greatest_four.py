a=671
b=833
c=86
d=3233

print("Greater is ")
if(a>b and a>c and a>d):
    print('a')
elif(b>c and b>d):
    print('b')
elif(c>d):
    print('c')
else:
    print('d')
