# list1 = [1,2,3,2,1]
# print("Given List is :",list1)
# demo = list1.copy()
# list1.reverse()
# if(demo == list1):
#     print(list1)
#     print("List is pallindrome")
# else:
#     print("list is not pallindrome")

list1 = ["1","abc1","abc","1"]
print("Given List is :",list1)
demo = list1.copy()
list1.reverse()
if(demo == list1):
    print(list1)
    print("List is pallindrome")
else:
    print(list1)
    print("list is not pallindrome")
