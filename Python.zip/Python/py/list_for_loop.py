list=(1,4,9,16,25,36,49,64,81)
ind =0
for item in list :
    if(item == 9):
        print('item ',item,'found at pos:',ind+1)
    else:
        print('item not found :')
    ind+=1
