import re  #regularexpression
data='Hello we are indians. hello Indians are good'
print(data)
print('Search string in data use search ')#method to get index of first occurence
res =re.search('^Hello',data)
if res :
    print('search of hello string found ')
else :
    print('search not found ')

print(re.findall('indians',data))
print(re.split('\s',data))
print(re.sub("\s",' * ',data))