class Car:
    name='newone'

    def show(self):
        print('show name',self.name)

class ToyotoCar(Car):
    def __init__(self,name):
        self.name = name

    def show(self):
        print('show name',self.name)

t1 = ToyotoCar('Fortunar') 
t1.show()
# t1.name="oldone"
# t1.show()
t2 = ToyotoCar('Tesla')
t2.show()
t1.show()

