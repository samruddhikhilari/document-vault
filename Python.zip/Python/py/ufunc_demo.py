import numpy as np
def myfunc(x,y):
    return x+y

myfunc = np.frompyfunc(myfunc,2,1)
print(myfunc([83,654,247,43],[3,25,26,31]))
print(type(myfunc))
#ufunc = universal function the functions names which takes reference of ufunc called ufunc
print(type(np.concatenate))