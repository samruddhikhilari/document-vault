letters = ("C","D","A","A","B","B","A")

print(letters)
count = letters.count("A")
print(count)

data = ["C","D","A","A","B","B","A"]
print(data)
data.sort()
print(data)