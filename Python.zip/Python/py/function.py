#default function
def show():
    return("heloo")

print(show())
print(show())
print(show(),'sam')

#parameterized function
def add(a,b):
    sum = a+b
    return sum

x = int(input('enter first value'))
y = int(input('enter second value'))

print('Addition is :',add(x,y))