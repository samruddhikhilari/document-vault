stud = {
"name" : "samruddhi",
   19 : {38.2,75},
   "marks" :98,
   "address":'shinde'
}
# print(stud)
# print(type(stud))
# print(len(stud))
# print()
# print("Student's marks is :",stud["marks"])
# print(stud.keys())
# print(stud.values())
# print(stud.items())
# print(stud.get("marks"))
stud["trade"]='IT'
print(stud)

'''
dict is heterogenuous
dict is mutable
dict is order
'''
