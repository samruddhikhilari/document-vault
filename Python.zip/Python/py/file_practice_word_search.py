word='javascript'
with open('practice.txt','r') as f:
    data = f.read()
    if(data.find(word) != -1): # word in data
        print('Word found in data')
    else:
        print('word not found')