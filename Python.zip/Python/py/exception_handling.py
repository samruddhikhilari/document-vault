#types of  error TypeErro NameErro common Exception 
try :
    no = int(input('enter a no'))
    if no%2 ==0:
        print(no,'is even')
    else:
        print(no,'is odd')
except TypeError:
    print('there is type error')
except NameError:
    print('there is name error')
except ValueError:
    print('there is value error')
else:
    print('there is no error')
finally:
    print('end of programming block ')

'''  try => to include error posibilities block
     except=>to handle throws error from try block have must have one block also more than one 
     else => when try have not error it will run
     finally => always executes although except run or else doesn't matters
'''

