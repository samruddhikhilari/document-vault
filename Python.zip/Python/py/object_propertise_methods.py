class Car:
    def __init__(self):
        #object s's propertise initiated only when s object will instantiated
        self.acc=False
        self.culch=False
        self.start=False
    
    #object method calls only with object name 
    def startmet(self):
        self.culch=True
        self.acc=True
        self.start=True
        print('car has been started')

s = Car()
s.startmet()