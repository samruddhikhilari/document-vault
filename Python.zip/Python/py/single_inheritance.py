class Car:
    @classmethod
    def start(self):
        print('start the car form start method of Car Class:')

    @staticmethod
    def stop():
        print('stop the car form stop method of Car Class:')

class ToyotoCar(Car):
    def dis(self):
        print('object"s dis method form ToyotoCar class')

t1 =ToyotoCar() 
t1.dis()  #object's method
ToyotoCar.start()  #class's method
t1.stop() #static method called by obj
ToyotoCar.stop() #static method called by class

