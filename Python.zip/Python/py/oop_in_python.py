#class creation
class Student:
    __name=" " #private property
    def __init__(self,name):
        self.__name = name
        print('Name of the stud :',self.__name)

s1 = Student('sam')
# print('Name of the stud :',s1.name)
s2 = Student('Khilari')
s3 =s2
s3.name='abc'
print(s3.name)
#class creation
# class Student:
#     __name="samruddhi"
#     def show():
#         print('Name of the stud :',Student.__name)

# s1 = Student()
# # print('Name of the stud :',s1.name)