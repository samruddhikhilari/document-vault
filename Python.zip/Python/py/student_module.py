import student
name = input('enter student name')
rollno = int(input('enter rollno of the student'))
marks = float(input('enter student marks'))
age = int(input('enter student age '))

stud ={
    'name':name,
    'rollno':rollno,
    'marks': marks,
    'age':age
}
student.display_stud(stud)