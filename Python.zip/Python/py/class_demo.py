class Student:
    college_name='GPA' 
    def __init__(self,name):
        self.name=name
    
    def show(self):
        print(self.college_name)
        print(self.name)

s1 = Student('abc')
s1.show()