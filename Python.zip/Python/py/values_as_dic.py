dic ={
    "name":"sam",
     'sub': {
        'maths':1,
        'a':3,
        'b':38
     }
}
print(dic)
print(dic["sub"]["maths"])
dic["dhdj"]=4747
a={37:3736}
dic.update(a)
b={7:336}
dic.update(b)
print(dic)

