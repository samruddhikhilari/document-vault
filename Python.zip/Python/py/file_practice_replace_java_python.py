newdata=''
with open('practice.txt','r') as f:
    data = f.read()
    newdata = data.replace('Java','Python')

with open('practice.txt','w') as f1:
    f1.write(newdata)