class Student:
    @staticmethod
    def show():
        print('this is an class method')

s = Student()
s.show()
Student.show()