marks=98.9
if(marks>=90):
    print("Grade A")
elif(marks>=80):
    print("Grade B")
elif(marks>=70):
    print("Grade C")
else:
    print("Grade D")

print('end of statements !!!') 
