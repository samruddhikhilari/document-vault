msg ='Hello sam'

i=0
while i<5:
    print(msg,i,end=' ',sep='/ ')
    i+=1
print('End of While Loop')