def add(a,b=10):
    sum = a+b
    return sum

x = int(input('enter first value'))

print('Addition is :',add(x))