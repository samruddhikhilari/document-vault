set1 ={37,67,6.7,98,23,}
# print(type(set1))
dic = {}
# print(type(dic))

set={38,283,293,273,67,23} 
print(set.pop())
set.add(3742)
print(set)
set.remove(38)
print(set)
print(set.union(set1))
print(set.intersection(set1))
'''
set is heterogenuous
set is immutable
set is unorder
'''