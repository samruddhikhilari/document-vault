
#simple function
def add(a):
    return 'name is '+a
print(add('student'))

#lambda function
val =lambda x,y:x*y
print(val(4,3))

#lambda function inside simple function
def add(a):
    return lambda b:a+b
var= add(12)
print(var(10))