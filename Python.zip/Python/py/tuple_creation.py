values=(10)
values=(383,83,28,47)
values=(13.1,22,3.3,11,22,8.8,44,55,66)
print(values.index(66))
print(values)
tuple1 = (1,)
#empty structures
l1=[]
d={}
s={0,}
t=()

print(values.count(11))
print(len(values))
print(type(values))

'''
 tuple is heterogenuous
tuple is immutable
tuple is order
'''