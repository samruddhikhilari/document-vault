num = 222222222
if(num%2==0):
    print(num,"is even ")
else:
    print(num,"is odd")