stud ={
    'name':'samruddhi khilari',
    'rollno':'23IF335',
    'marks': 98.9,
    'age':20
}
def display_stud(stud):
    print('****************** Student Details ****************')
    print('Name of the Student is :',stud['name'])
    print('Roll no of ',stud['name'],'is :', stud['rollno'])
    print('Marks is :',stud['marks'])
    print('Age :',stud['age'])

# display_stud(stud)