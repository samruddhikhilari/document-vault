print("Enter 3 favourite movies names")
mov1 = input("Movie 1:")
mov2  = input("Movie 2:")
mov3 = input("Movie 3:")
# movies = [mov1,mov2,mov3]
moview =[]
moview.append(mov1)
print(moview)
moview.append(mov2)
print(moview)
moview.append(mov3)
print(moview)
