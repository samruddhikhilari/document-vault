class Demo:
    def __init__(self,name):
        self.name=name

    def show(self):
        print(self.name)

    def __add__(self,obj):
       print (self.name + obj.name)

d1 = Demo('abc')
d2 = Demo('xyz')
d1 + d2 