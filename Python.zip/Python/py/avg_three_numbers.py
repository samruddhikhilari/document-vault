a = int(input('enter value for a '))
b = int(input('enter value for b '))
c = int(input('enter value for c '))

#defination of the function
#greates of three numbers
def find(x,y,z):

    if(x<0 or y<0 or z<0):
        print('enter input is wrong')
    else:
        if(x>y and x>z):
            print(x,'a is greater value')
        if(y>x and y>z):
             print(y,'b is greater value')
        if(z>x and z>y):
             print(z,'c is greater value')

#avergae of three numbers
def cal(x,y,z):
    if(x<0 or y<0 or z<0):
        print('enter input is wrong')
    else:
        avg = (x+y+z)/3
        print('Average value is ',avg)

#take choice as input
print('=======================================')
print('1.Greatest')
print('2.Average')
choice = int(input('choose one of above'))
if(choice>0):
    if(choice==1):
        find(a,b,c)
    else:
        if(choice==2):
            cal(a,b,c)
