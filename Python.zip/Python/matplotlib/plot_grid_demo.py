import matplotlib.pyplot as plt
import numpy as np

x = np.array([1,2,3,45,5,8])
y = np.array([8,4,3,2,64,6])

#grid with x and u axis
# plt.plot(x,y)
# plt.grid()
# plt.show()

#grid with only y axis
plt.plot(x,y)
plt.grid(axis='y')
plt.show()

#grid line properties
plt.plot(x,y)
plt.grid(axis='x',ls='dashed',lw=2,color='k')
plt.show()