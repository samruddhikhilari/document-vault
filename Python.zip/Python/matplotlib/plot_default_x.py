import matplotlib.pyplot as plt
import numpy as np

y = np.array([81,44,32,12,64,67])

plt.plot(y,'o',linestyle='dashed') #when only y gives x values considered as the index values 
plt.show()