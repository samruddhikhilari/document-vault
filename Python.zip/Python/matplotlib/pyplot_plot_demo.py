import matplotlib.pyplot as plt
import numpy as np

xpoints= np.array([2,32,643,1])
ypoints = np.array([3,300,400,10])

xpoints= np.array([4,0,3,2,11.10])
ypoints = np.array([20,30,10,350,23])


plt.plot(xpoints,ypoints,linewidth=4.0,color='red',ls='dashed',marker='d',markeredgecolor='blue',markerfacecolor='pink')
plt.show()