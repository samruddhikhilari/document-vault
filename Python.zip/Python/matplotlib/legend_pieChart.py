import matplotlib.pyplot as plt
import numpy as np

l = np.array(['apple','banana','strawberry','grapes'])
v = np.random.randint(1,101,4)

#more properties
plt.pie(v,labels=l,startangle=180,explode=[0,0,0.25,0],shadow=True,colors=(np.array(['red','yellow','darkred','green'])))
plt.legend(title='legend of colors',loc='lower right')
plt.show()
