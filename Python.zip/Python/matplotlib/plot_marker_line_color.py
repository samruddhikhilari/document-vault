import matplotlib.pyplot as plt
import numpy as np

x = np.array([1,2,3,45,5,8])
y = np.array([8,4,3,2,64,6])

#use of marker line and color
plt.plot(x,y,'s:g',linewidth='2')
plt.show()
# plt.plot(x,y,marker='*',linestyle=':',color='g',width='2')
# plt.show()