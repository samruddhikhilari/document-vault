import matplotlib.pyplot as plt
import numpy as np

x = np.array(['A','B','C','D'])
y = np.array([29,32,53,21])

# plt.barh(x,y)
# plt.show()

#more properties of bar
# plt.barh(x,y,color='red',height=0.5)
# plt.show()

#individual properties of bar
colors=['red','green','blue','yellow']
heights=[0.1,0.4,0.6,0.9]

plt.barh(x,y,color=colors,height=0.1)
plt.show()