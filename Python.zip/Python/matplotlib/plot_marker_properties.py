import matplotlib.pyplot as plt
import numpy as np

x = np.array([1,2,3,45,5,8])
y = np.array([8,4,3,2,64,6])

'''
marker properties
marker 
ms => marker size
mfc =>marker face color
mec =>marker edge color
mes => marker edge size
'''

#marker with line
# plt.plot(x,y,marker='o',ms=20,mfc='r',mec='b')
# plt.show()

#marker without line
plt.plot(x,y,marker='o',color='blue',ms=10,mfc='hotpink',mec='#000000',mew=5) #rrggbb
plt.show()