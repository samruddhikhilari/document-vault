import matplotlib.pyplot as plt
import numpy as np

x = np.array([1,2,3,45,5,8])
y = np.array([8,4,3,2,64,6])

font2={'family':'Arial','style':'italic','size':10,'color':'green'}
font1={'family':'Arial','style':'italic','size':13,'color':'blue'}

#label and title location changed
plt.plot(x,y)
plt.xlabel('height',loc='left',fontdict=font2)
plt.ylabel('students',loc='top',fontdict=font2)
plt.title('Graph of student height analysis',loc='center',fontdict=font1)
plt.show()
