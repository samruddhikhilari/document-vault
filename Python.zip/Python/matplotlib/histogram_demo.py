import matplotlib.pyplot as plt
import numpy as np

x=np.random.normal(170,10,150)

plt.hist(x,bins=5,orientation='horizontal',cumulative=True,stacked=True)
plt.show()