import matplotlib.pyplot as plt
import numpy as np

x =np.array([2,5,3,4,1])
y = np.array([4,5,6,2,3])

plt.subplot(1,4,1)
plt.plot(x,y)

plt.subplot(1,4,2)
plt.plot([1,2,3,4,5],[10,11,12,13,14])
plt.show()