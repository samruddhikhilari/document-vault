import matplotlib as mplt

print(mplt.__version__)
print(mplt.colormaps())