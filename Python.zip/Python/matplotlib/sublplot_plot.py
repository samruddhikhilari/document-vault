import matplotlib.pyplot as plt
import numpy as np

font1 ={'family':'Arial','color':'blue','size':'13'}
font2 ={'family':'Arial','color':'green','size':'5'}

#plot 1
x = np.array([1,2,4])
y = np.array([4,5,6])

plt.subplot(2,3,1) #2rows 3col 1stindexno
plt.xlabel('xlabel',loc='left',fontdict=font2)
plt.ylabel('ylabel',loc='top',fontdict=font2)
plt.plot(x,y)

#plot2
x = np.array([9,2,3])
y = np.array([3,2,1])

plt.subplot(2,3,2) #2rows 3col 2indexno
plt.xlabel('xlabel',loc='left',fontdict=font2)
plt.ylabel('ylabel',loc='top',fontdict=font2)
plt.plot(x,y)

#plot 3
x = np.array([1,2,4])
y = np.array([4,5,6])

plt.subplot(2,3,3) #2rows 3col 3indexno
plt.xlabel('xlabel',loc='left',fontdict=font2)
plt.ylabel('ylabel',loc='top',fontdict=font2)
plt.plot(x,y)

#plot4
x = np.array([9,2,3])
y = np.array([3,2,1])

plt.subplot(2,3,4) #2rows 3col 4indexno
plt.xlabel('xlabel',loc='left',fontdict=font2)
plt.ylabel('ylabel',loc='top',fontdict=font2)
plt.plot(x,y)

#plot 5
x = np.array([1,2,4])
y = np.array([4,5,6])

plt.subplot(2,3,5) #2rows 3col 5indexno
plt.xlabel('xlabel',loc='left',fontdict=font2)
plt.ylabel('ylabel',loc='top',fontdict=font2)
plt.plot(x,y)

#plot 6
x = np.array([9,2,3])
y = np.array([3,2,1])

plt.subplot(2,3,6) #2rows 3col 6indexno
plt.xlabel('xlabel',loc='left',fontdict=font2)
plt.ylabel('ylabel',loc='top',fontdict=font2)

plt.plot(x,y)
# plt.suptitle('this is a super title',loc='left')
plt.show()