import matplotlib.pyplot as plt
import numpy as np

x = np.array([1,2,3,45,5,8])
y = np.array([8,4,3,2,64,6])

#line properties => linestyle ls linewidth lw
plt.plot(x,y,linestyle='--',lw='1.5',color='black')
plt.show()