import matplotlib.pyplot as plt 
import numpy as np

x = np.array([11,22,44,31,14,52,61,57,11,22,44,31])
y = np.array([14,52,61,57,11,22,44,31,14,52,61,57])

#single alpha
# plt.scatter(x,y,alpha=0.2)
# plt.show()

#multiple alphas
# alphas=[0.3,0.8,0.19,0.50]
# plt.scatter(x,y,alpha=alphas)
# plt.show()

# #multiple size , color, alpa
# alphas=[0.3,0.8,0.19,0.50]  #individual opacities
# sizes=[15,20,25,30]         #individual sizes
# colors=[10,20,30,40]        #individual colors

# plt.scatter(x,y,alpha=alphas,s=sizes,c=colors,cmap='nipy_spectral')
# plt.show(x)

#colorbar
plt.scatter(x,y,c=x,cmap='viridis',s=y,alpha=0.9)
plt.colorbar()
plt.show()