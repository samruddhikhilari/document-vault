import matplotlib.pyplot as plt
import numpy as np

x = np.array([1,2,3,45,5,8])
y = np.array([8,4,3,2,64,6])

print(np.info(plt.legend()))
plt.plot(x,color='r',label='first')
plt.plot(y,c='g',label='second')
plt.legend(loc='right')
plt.show()