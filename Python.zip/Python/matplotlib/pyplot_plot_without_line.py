import matplotlib.pyplot as plt
import numpy as np

x = np.array([3,24,32,23,43,63])
y = np.array([1,23,4,5,6,7])
x1 = np.array([9,27,35,27,49,66])
y1 = np.array([6,28,4,7,8,9])

# use of marker
# plt.plot(x,y,'*') #plot(x,y,marker|line|color)
# plt.show()

# use of solid line
# plt.plot(x,y,'-') #plot(x,y,marker|line|color)
# plt.show()

# use of dotted line
# plt.plot(x,y,':') #plot(x,y,marker|line|color)
# plt.show()

# use of dashed line
# plt.plot(x,y,'--') #plot(x,y,marker|line|color)
# plt.show()

# use of marker, line and color
plt.subplot(1,3,1)
plt.plot(x,y,'.-r') #plot(x,y,marker|line|color)
plt.subplot(1,3,2)
plt.plot(x1,y1,'s--b') #plot(x,y,marker|line|color)
plt.subplot(1,3,3)
plt.plot([11,12,13,14,15,16],[20,17,18,19,21,22],'s--b')
plt.show()

