import matplotlib.pyplot as plt
import numpy as np

x = np.array([11,22,44,31])
y = np.array([14,52,61,57])

#single color
# plt.scatter(x,y,c='red')
# plt.show()

#multiple color
# colors=['red','green','blue','yellow']
# plt.scatter(x,y,c=colors)
# plt.show()

# color map
colors=[10,20,30,40]
plt.scatter(x,y,c=colors,cmap='viridis')
plt.show()