import matplotlib.pyplot as plt
import numpy as np

l = np.array(['apple','banana','strawberry','grapes'])
v = np.random.randint(1,101,4) #low, hight and count(len)

# plt.pie(v,labels=l)
# plt.show()

#more properties
plt.pie(v,labels=l,startangle=90,explode=[0.25,0.25,0.25,0.25],shadow=True,colors=(np.array(['red','yellow','darkred','green'])))
plt.show()
'''
values,explode,color
labels,startangle,shadow

'''