import matplotlib.pyplot as plt
import numpy as np

x = np.array([3,24,32,23,43,63])
y = np.array([1,23,4,5,6,7])

#plot with only line
plt.plot(x,y)
plt.show()

#plot with only marker
plt.plot(x,y,'o') # 'marker|line|color' by giveing only as '' lit overides other properties i.e line and color
plt.show()

#plot with line and marker
plt.plot(x,y,marker='o')
plt.show()

'''
line referencess
- solid
-- dashed
: dotted
*****************************
color references
r red
g green
b blue
k black
w white
y yellow
m magenta
'''