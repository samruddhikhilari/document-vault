import matplotlib.pyplot as plt 
import numpy as np

x = np.array([11,22,44,31])
y = np.array([14,52,61,57])

#single size
# plt.scatter(x,y,s=15)
# plt.show()

#multiple size
sizes=[15,20,25,30]
plt.scatter(x,y,s=sizes)
plt.show()

