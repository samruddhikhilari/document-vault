import matplotlib.pyplot as plt
import numpy as np

x = np.array([1,2,3,45,5,8])
y = np.array([8,4,3,2,64,6])

#label and title
# plt.plot(x,y)
# plt.xlabel('height')
# plt.ylabel('students')
# plt.title('Graph of student height analysis')
# plt.show()

#label and title location changed
plt.plot(x,y)
plt.xlabel('height',loc='left')
plt.ylabel('students',loc='top')
plt.title('Graph of student height analysis',loc='left')
plt.show()