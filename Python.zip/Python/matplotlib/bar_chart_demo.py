import matplotlib.pyplot as plt
import numpy as np

x = np.array(['A','B','C','D'])
y = np.array([29,32,53,21])

# plt.bar(x,y)
# plt.show()

#more properties of bar
# plt.bar(x,y,color='red',width=0.5)
# plt.show()

#individual properties of bar
colors=['red','green','blue','yellow']
widths=[0.1,0.4,0.6,0.9]

plt.bar(x,y,color=colors,width=widths)
plt.legend()
plt.show()