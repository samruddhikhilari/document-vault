import matplotlib.pyplot as plt
import numpy as np

#scatter plot1
x = np.array([1,2,41,4,33,25,43,42])
y = np.array([4,5,6,47,42,12,62,82])

plt.scatter(x,y)

#scatter plot2
x = np.array([11,22,44,31,33,55,23,62])
y = np.array([14,52,61,57,47,92,62,82])

plt.scatter(x,y)
plt.show()